DOMAIN = "smyoo"
PLATFORMS = ["switch"] # 假设目前只有开关平台
